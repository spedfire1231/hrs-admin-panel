const express = require("express");
const router = express.Router();
const Faq = require("../models/Faq");
const auth = require("../middleware/auth"); // твій JWT middleware

// GET /api/faq
router.get("/", auth, async (req, res) => {
  try {
    const { role, email } = req.user;

    const filter = (role === "owner" || role === "admin")
      ? {}
      : { ownerEmail: email };

      // 🌍 ФІЛЬТР ПО МОВІ
    if (language) {
      filter.language = language;
    }

    const faq = await Faq.find(filter)
      .sort({ updatedAt: -1 })
      .select("_id name content language category ownerEmail updatedAt createdAt isActive tags usageCount lastUsed");

    res.json(faq);
  } catch (e) {
    res.status(500).json({ message: "Failed to load faq" });
  }
});

// UPDATE faq
// PUT /api/faq/:id
router.put("/:id", auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { content } = req.body;
    const { role, email } = req.user;

    const faq = await Faq.findById(id);
    if (!faq) {
      return res.status(404).json({ message: "Faq not found" });
    }

    // доступ: owner/admin або власник
    if (
      role !== "owner" &&
      role !== "admin" &&
      faq.ownerEmail !== email
    ) {
      return res.status(403).json({ message: "Access denied" });
    }

    faq.content = content;
    faq.updatedAt = new Date();
    await faq.save();

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ message: "Failed to update faq" });
  }
});

// DELETE faq
// DELETE /api/faq/:id
router.delete("/:id", auth, async (req, res) => {
  try {
    const { id } = req.params;
    const { role, email } = req.user;

    const faq = await Faq.findById(id);
    if (!faq) {
      return res.status(404).json({ message: "Faq not found" });
    }

    if (
      role !== "owner" &&
      role !== "admin" &&
      faq.ownerEmail !== email
    ) {
      return res.status(403).json({ message: "Access denied" });
    }

    await faq.deleteOne();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ message: "Failed to delete faq" });
  }
});

// CREATE faq
// POST /api/faq
router.post("/", auth, async (req, res) => {
  try {
    const { name, content = "", language = "en" } = req.body;
    const { email, role } = req.user;

    if (!name || !name.trim()) {
      return res.status(400).json({ message: "Faq name required" });
    }

    // тільки owner / admin / hr
    if (!["owner", "admin", "hr"].includes(role)) {
      return res.status(403).json({ message: "Access denied" });
    }

    const faq = await Faq.create({
      name: name.trim(),
      content,
      language,
      ownerEmail: email,
      isActive: true,
      usageCount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    res.json({ ok: true, faq });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Failed to create faq" });
  }
});


module.exports = router;
