export const confirmDialog = (msg: string): boolean =>
  window.confirm(msg);