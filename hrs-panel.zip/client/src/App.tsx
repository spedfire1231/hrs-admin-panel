import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import { AuthProvider } from "./context/AuthContext";
import { SocketProvider } from "./context/SocketContext";

import PrivateRoute from "./components/PrivateRoute";
import Layout from "./components/Layout";

// pages
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Users from "./pages/Users";
import Scripts from "./pages/Scripts";
import FAQ from "./pages/FAQ";
import Questions from "./pages/Questions";
import Settings from "./pages/Settings";

function App() {
  return (
    <AuthProvider>
      <SocketProvider>
        <Routes>
          {/* ---------- PUBLIC ---------- */}
          <Route path="/login" element={<Login />} />

          {/* ---------- PROTECTED ---------- */}
          <Route element={<PrivateRoute />}>
            <Route element={<Layout />}>
              <Route path="/" element={<Dashboard />} />

              {/* admin only */}
              <Route
                path="/users"
                element={
                  <PrivateRoute allowedRoles={["admin"]}>
                    <Users />
                  </PrivateRoute>
                }
              />

              {/* admin + hr */}
              <Route
                path="/scripts"
                element={
                  <PrivateRoute allowedRoles={["admin", "hr"]}>
                    <Scripts />
                  </PrivateRoute>
                }
              />

              <Route
                path="/faq"
                element={
                  <PrivateRoute allowedRoles={["admin", "hr"]}>
                    <FAQ />
                  </PrivateRoute>
                }
              />

              <Route
                path="/questions"
                element={
                  <PrivateRoute allowedRoles={["admin", "hr"]}>
                    <Questions />
                  </PrivateRoute>
                }
              />

              <Route
                path="/settings"
                element={
                  <PrivateRoute allowedRoles={["admin"]}>
                    <Settings />
                  </PrivateRoute>
                }
              />
            </Route>
          </Route>

          {/* ---------- FALLBACK ---------- */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </SocketProvider>
    </AuthProvider>
  );
}

export default App;