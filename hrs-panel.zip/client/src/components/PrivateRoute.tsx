import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export const PrivateRoute = ({
  children,
  allowedRoles,
}: {
  children: JSX.Element;
  allowedRoles?: string[];
}) => {
  const { user, role, loading } = useAuth();

  if (loading) return null;
  if (!user) return <Navigate to="/login" />;

  if (allowedRoles && !allowedRoles.includes(role!)) {
    return <Navigate to="/login" />;
  }

  return children;
};

export default PrivateRoute;